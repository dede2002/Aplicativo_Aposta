package com.example.apostas

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.apostas.data.Aposta
import com.example.apostas.data.StatusAposta
import com.example.apostas.ui.theme.CadastroApostaActivity
import com.example.apostas.ui.theme.ApostasTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val apostas = listOf(
            Aposta(
                descricao = "Palmeiras x Flamengo",
                casa = "Bet365",
                valor = 100.0,
                odds = 2.5,
                status = StatusAposta.ABERTA,
                retornoPotencial = 250.0,
                lucro = 0.0
            ),
            Aposta(
                descricao = "Vasco x Bahia",
                casa = "Betano",
                valor = 50.0,
                odds = 3.1,
                status = StatusAposta.GANHA,
                retornoPotencial = 155.0,
                lucro = 105.0
            )
        )

        setContent {
            ApostasTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TelaPrincipal(apostas = apostas) {
                        val intent = Intent(this, CadastroApostaActivity::class.java)
                        startActivity(intent)
                    }
                }
            }
        }
    }
}

@Composable
fun TelaPrincipal(apostas: List<Aposta>, onNovaApostaClick: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {

        Button(
            onClick = onNovaApostaClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Text("Nova Aposta")
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(apostas) { aposta ->
                CardAposta(aposta)
            }
        }
    }
}

@Composable
fun CardAposta(aposta: Aposta) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "Aposta: ${aposta.descricao}")
            Text(text = "Casa: ${aposta.casa}")
            Text(text = "Valor: R$ ${aposta.valor}")
            Text(text = "Odds: ${aposta.odds}")
            Text(text = "Status: ${aposta.status}")
            Text(text = "Retorno Potencial: R$ ${aposta.retornoPotencial}")
            Text(text = "Lucro: R$ ${aposta.lucro}")
        }
    }
}
