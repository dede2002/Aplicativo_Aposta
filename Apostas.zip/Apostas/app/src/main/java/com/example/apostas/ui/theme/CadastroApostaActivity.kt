package com.example.apostas.ui.theme

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.apostas.data.Aposta
import com.example.apostas.data.StatusAposta


class CadastroApostaActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ApostasTheme {
                FormularioCadastro()
            }
        }
    }
}

@Composable
fun FormularioCadastro() {
    var descricao by remember { mutableStateOf("") }
    var casa by remember { mutableStateOf("") }
    var valor by remember { mutableStateOf("") }
    var odds by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(StatusAposta.ABERTA) }

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(value = descricao, onValueChange = { descricao = it }, label = { Text("Descrição da aposta") })
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = casa, onValueChange = { casa = it }, label = { Text("Casa de aposta") })
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = valor, onValueChange = { valor = it }, label = { Text("Valor apostado") })
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(value = odds, onValueChange = { odds = it }, label = { Text("Odds") })
        Spacer(modifier = Modifier.height(8.dp))

        // Seleção de status (ABERTA, GANHA, PERDIDA)
        Row {
            StatusAposta.entries.forEach { opcao ->
                Row(modifier = Modifier.padding(end = 8.dp)) {
                    RadioButton(selected = status == opcao, onClick = { status = opcao })
                    Text(text = opcao.name)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            val valorDouble = valor.toDoubleOrNull() ?: 0.0
            val oddsDouble = odds.toDoubleOrNull() ?: 0.0
            val retorno = valorDouble * oddsDouble
            val lucro = when (status) {
                StatusAposta.GANHA -> retorno - valorDouble
                StatusAposta.PERDIDA -> -valorDouble
                StatusAposta.ABERTA -> 0.0
            }

            val novaAposta = Aposta(
                descricao = descricao,
                casa = casa,
                valor = valorDouble,
                odds = oddsDouble,
                status = status,
                retornoPotencial = retorno,
                lucro = lucro
            )

            Log.d("CadastroAposta", "Aposta criada: $novaAposta")
        }) {
            Text("Salvar Aposta")
        }
    }
}
